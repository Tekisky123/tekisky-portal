function Batches() {
    return (
        <div>You are at Batches page</div>
    )
}

export default Batches;