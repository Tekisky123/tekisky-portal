function Enquiry() {
    return (
        <div>You are at Enquiry Page</div>
    )
}

export default Enquiry;