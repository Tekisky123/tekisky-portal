function Fees() {
    return (
        <div>You are at Fees page</div>
    )
}

export default Fees;