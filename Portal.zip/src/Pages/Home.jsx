function Home() {

    return (
        <>
            <h1 style={{ textAlign: "center" }}>Welcome to Tekisky</h1>
        </>
    )
}

export default Home;