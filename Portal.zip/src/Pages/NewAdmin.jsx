function NewAdmin() {
    return (
        <div>You are at NewAdmin page</div>
    )
}

export default NewAdmin;