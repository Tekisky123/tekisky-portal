function Users() {
  return (
    <div>You are at Users page</div>
  )
}

export default Users;